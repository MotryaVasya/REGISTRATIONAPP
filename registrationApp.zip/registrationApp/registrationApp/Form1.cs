﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace registrationApp
{
    public partial class Form1 : Form
    {
        string cs = "Data Source=K-306-TEACHER;Initial Catalog=Vasya;Integrated Security=True;";
        private bool VerifyPassword(string password, string hashedPassword)
        {
            return BCrypt.Net.BCrypt.Verify(password, hashedPassword);
        }
        private void Login(string login, string password)
        {
            using (SqlConnection conn = new SqlConnection(cs))
            {
                string sql = $"select passwordHash from students where username = '{login}'";
                SqlCommand cmd = new SqlCommand(sql,conn);
                conn.Open();
                var result = cmd.ExecuteScalar();
                if (result != null)
                {
                    string hashedPassword = result.ToString();
                    if (VerifyPassword(password,hashedPassword))
                    {
                        //получить id и передать на форму 3
                        Form3 form3 = new Form3();
                        form3.ShowDialog();
                    }
                }
            }
        }
        public Form1()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Login(textBox1.Text, textBox2.Text);
        }
    }
}
